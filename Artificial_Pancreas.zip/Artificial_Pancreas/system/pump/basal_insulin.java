package pump;

public class basal_insulin 
{
	public basal_insulin()
	{
		
	}
	
	public void Result()
	{
		System.out.println("Basal Insulin Infused");
	}
	
}
