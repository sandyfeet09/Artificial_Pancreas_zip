package pump;

public class bolus_insulin 
{
	public bolus_insulin()
	{
		
	}
	public void Result()
	{
		System.out.println("Bolus Insulin Infused");
	}
	
}
